/* Browser fallback. `npm run build:web` replaces this file with the Capacitor bridge bundle. */
window.GoodsMakerNative = window.GoodsMakerNative || { saveBlob: async () => false };
