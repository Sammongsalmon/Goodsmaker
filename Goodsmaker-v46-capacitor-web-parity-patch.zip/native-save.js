(() => {
  'use strict';

  const Capacitor = window.Capacitor;
  const isNative = () => {
    try { return !!Capacitor?.isNativePlatform?.(); }
    catch (_) { return false; }
  };

  if (!Capacitor?.registerPlugin) {
    window.GoodsMakerNative = { async saveBlob() { return false; } };
    return;
  }

  const Filesystem = Capacitor.registerPlugin('Filesystem');
  const Share = Capacitor.registerPlugin('Share');
  const DIRECTORY_CACHE = 'CACHE';
  const CHUNK_BYTES = 64 * 1024;

  function safeFileName(name) {
    const cleaned = String(name || 'goods-maker-output.png')
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
      .trim();
    return cleaned || 'goods-maker-output.png';
  }

  function bytesToBase64(bytes) {
    let binary = '';
    const step = 0x4000;
    for (let offset = 0; offset < bytes.length; offset += step) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + step));
    }
    return btoa(binary);
  }

  async function blobToBase64(blob) {
    let buffer;
    if (typeof blob.arrayBuffer === 'function') {
      buffer = await blob.arrayBuffer();
    } else {
      buffer = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = () => reject(reader.error || new Error('파일 변환 실패'));
        reader.onload = () => resolve(reader.result);
        reader.readAsArrayBuffer(blob);
      });
    }
    return bytesToBase64(new Uint8Array(buffer));
  }

  async function writeBlob(path, blob) {
    if (!(blob instanceof Blob) || blob.size <= 0) {
      throw new Error('저장할 파일 데이터가 비어 있습니다.');
    }

    let offset = 0;
    let first = true;
    while (offset < blob.size) {
      const end = Math.min(blob.size, offset + CHUNK_BYTES);
      const data = await blobToBase64(blob.slice(offset, end, blob.type));
      if (first) {
        await Filesystem.writeFile({
          path,
          data,
          directory: DIRECTORY_CACHE,
          recursive: true
        });
        first = false;
      } else {
        await Filesystem.appendFile({
          path,
          data,
          directory: DIRECTORY_CACHE
        });
      }
      offset = end;
    }

    const stat = await Filesystem.stat({ path, directory: DIRECTORY_CACHE });
    if (Number.isFinite(Number(stat.size)) && Number(stat.size) !== blob.size) {
      try { await Filesystem.deleteFile({ path, directory: DIRECTORY_CACHE }); } catch (_) {}
      throw new Error(`저장된 파일 크기가 원본과 다릅니다. (${stat.size}/${blob.size})`);
    }
    return stat;
  }

  window.GoodsMakerNative = {
    async saveBlob(blob, requestedName) {
      if (!isNative()) return false;

      const name = safeFileName(requestedName);
      const path = `goods-maker/${Date.now()}-${name}`;
      const stat = await writeBlob(path, blob);
      const uri = stat.uri || (await Filesystem.getUri({ path, directory: DIRECTORY_CACHE })).uri;

      await Share.share({
        title: name,
        text: '굿즈 메이커에서 만든 파일',
        files: [uri],
        dialogTitle: '파일 저장 또는 공유'
      });
      return true;
    }
  };
})();
