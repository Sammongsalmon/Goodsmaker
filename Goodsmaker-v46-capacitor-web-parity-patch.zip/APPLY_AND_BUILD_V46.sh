#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
cd "$ROOT"

for required in index.html app.js style.css layout.js package.json; do
  if [ ! -f "$required" ]; then
    echo "저장소 루트에서 실행해 주세요. 누락: $required" >&2
    exit 1
  fi
done

npm ci --no-audit --no-fund
npm run verify:functions
npm run android:sync

printf '\n기능 연결과 Capacitor 동기화가 완료되었습니다.\n'
printf '로컬 APK: (cd android && ./gradlew assembleDebug)\n'
printf 'Codespaces: npm run apk:codespaces\n'
printf 'GitHub: 커밋·푸시 후 Actions의 goodsmaker-v46-capacitor-apk 아티팩트 사용\n'
