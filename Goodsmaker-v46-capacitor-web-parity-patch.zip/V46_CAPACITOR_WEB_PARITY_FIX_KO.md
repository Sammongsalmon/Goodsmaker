# 굿즈 메이커 v46 — 웹 기능 동일 동작용 Capacitor 수정

## 목적

현재 APK의 화면 스타일과 레이아웃은 그대로 유지하면서, 웹 메인에서 정상 동작하는 파일 불러오기·다중 이미지 처리·배경 미리보기·내보내기를 실제 Capacitor Android 앱에서도 같은 코드 경로로 사용하도록 수정했다.

## 원인과 수정

### 1. 스티커·외곽선/배경 파일 선택

기존 APK는 보이는 일반 버튼이 완전히 숨겨진 파일 입력에 `input.click()`을 호출하는 구조였다. Android WebView에서는 이 합성 클릭이 네이티브 파일 선택 요청으로 전달되지 않을 수 있었다.

v46에서는 코롯토 탭과 같은 구조로 통일했다.

- 보이는 드롭존 자체가 `<label for="...">`로 실제 파일 입력과 직접 연결된다.
- 실제 `<input type="file">`가 드롭존 전체를 투명하게 덮어 터치 지점 자체가 파일 입력이 된다.
- 스티커 `multiFileInput`과 외곽선/배경 `makerFileInput` 모두 `multiple`과 `accept="image/*"`를 유지한다.
- 가짜 선택 버튼, 숨겨진 입력에 대한 `.click()` 호출, 별도 프록시 이벤트는 제거했다.
- 선택된 파일은 웹 메인과 같은 `FileReader.readAsDataURL()` → `addStickerFiles()` / `addMakerFiles()` 경로로 처리한다.

### 2. 실제 Capacitor Android 앱 구조

- `MainActivity`는 `com.getcapacitor.BridgeActivity`를 상속한다.
- 웹 자산은 `dist`에서 Capacitor Android 프로젝트로 동기화한다.
- HTML 파일 입력은 Capacitor WebView의 네이티브 파일 선택 처리로 연결된다.
- 외곽선/스티커의 여러 이미지 선택은 웹과 같은 `FileList`를 앱 코드가 받는다.

### 3. 손상 없는 내보내기

PNG·JPG·SVG·AI에서 웹이 만든 원본 `Blob`을 그대로 사용한다.

- PNG/JPG는 `canvas.toBlob()`을 우선 사용하고 WebView 호환용 `toDataURL()` 대체 경로를 둔다.
- Capacitor에서는 `@capacitor/filesystem`으로 캐시 파일을 생성한다.
- 큰 출력도 메모리 문자열 하나로 합치지 않고 64 KiB 단위로 base64 변환해 `writeFile`/`appendFile`로 기록한다.
- 기록 후 `Filesystem.stat()`의 파일 크기와 원본 Blob 크기를 비교한다.
- 정확히 기록된 캐시 URI만 `@capacitor/share`의 `files` 배열로 전달한다.
- 네이티브 앱에서 플러그인 저장이 실패하면 브라우저 다운로드로 조용히 우회하지 않고 오류를 표시해 손상 파일이 생성된 것처럼 보이지 않게 했다.

## 스타일·레이아웃 보존

다음 파일은 바이트 단위로 고정했으며 이번 기능 수정에서 변경하지 않았다.

```text
style.css  bd200d47098aebb1d6ea12f7b959ef7a778bde16acc5ebb2ca5a6838ae4dbc25
layout.js  833bbef4bcd10e25fadfcc4355bac556218b807bb1fd1cb7e826fa73c4cdbef9
```

`Goodsmaker-v46-capacitor-web-parity-patch.zip`에는 두 파일을 아예 넣지 않았다. 현재 저장소의 화면 파일이 그대로 남는다.

## 자동 검증 결과

412×915 모바일 뷰포트에서 실제 보이는 드롭존을 눌러 파일 선택 이벤트를 확인했다.

```text
스티커: 파일 선택창 열림 → 이미지 2장 선택 → 상태 2개
외곽선/배경: 파일 선택창 열림 → 이미지 2장 선택 → 상태 2개
배경색 변경: 미리보기 캔버스 데이터 변경, 상태에 “배경 적용” 표시
JavaScript 실행 오류: 0개
```

웹 출력물을 외부 파서로 다시 열어 확인했다.

```text
스티커 PNG   12,455 bytes   Pillow 검증 통과
스티커 SVG   73,587 bytes   XML 파싱 통과
스티커 AI    2,312,072 bytes   PDF 1.4 / 1페이지 검증 통과
메이커 PNG   18,591 bytes   Pillow 검증 통과
메이커 JPG   6,836 bytes   Pillow 검증 통과
```

네이티브 저장 브리지는 3,158,073바이트의 무작위 바이너리를 49개 조각으로 기록해 재조립했고, 원본과 기록 결과의 SHA-256이 동일한 것을 확인했다.

## GitHub Actions에서 APK 만들기

패치를 현재 저장소 루트에 덮어쓴 뒤 커밋·푸시하면 `.github/workflows/android-apk.yml`이 APK를 만든다.

```bash
unzip -o Goodsmaker-v46-capacitor-web-parity-patch.zip -d .
npm ci
npm run verify:functions
git add .
git commit -m "Capacitor 파일 불러오기와 내보내기 복구"
git push
```

GitHub의 **Actions → Build Goods Maker Capacitor APK → 가장 최근 실행 → Artifacts**에서 `goodsmaker-v46-capacitor-apk`를 받는다.

Codespaces 안에서 직접 만들 때는 다음 명령을 사용한다.

```bash
npm run apk:codespaces
```

결과:

```text
downloads/goodsmaker-v46-capacitor.apk
```

## 이 실행 환경의 제한

현재 작업 환경에는 Android SDK와 Gradle 배포본이 없고 외부 빌드 의존성을 받을 수 없어, 여기서 실제 APK를 컴파일했다고 주장하지 않는다. 대신 실제 Capacitor Android 프로젝트, GitHub Actions 빌드, Codespaces 빌드 스크립트와 기능 검증 결과를 함께 제공한다. 실제 Android 기기 파일 앱과 공유 시트의 최종 동작은 빌드된 APK를 기기에 설치해 확인해야 한다.
