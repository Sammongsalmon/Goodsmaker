import fs from 'node:fs';
import crypto from 'node:crypto';

const frozenVisualHashes = {
  'style.css': 'bd200d47098aebb1d6ea12f7b959ef7a778bde16acc5ebb2ca5a6838ae4dbc25',
  'layout.js': '833bbef4bcd10e25fadfcc4355bac556218b807bb1fd1cb7e826fa73c4cdbef9'
};

function sha256(path) {
  return crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
}
function text(path) { return fs.readFileSync(path, 'utf8'); }
function requireText(path, patterns) {
  const source = text(path);
  for (const pattern of patterns) {
    if (!source.includes(pattern)) throw new Error(`${path}: missing ${pattern}`);
  }
}
function forbidText(path, patterns) {
  const source = text(path);
  for (const pattern of patterns) {
    if (source.includes(pattern)) throw new Error(`${path}: forbidden legacy wiring remains: ${pattern}`);
  }
}

for (const [path, expected] of Object.entries(frozenVisualHashes)) {
  const actual = sha256(path);
  if (actual !== expected) throw new Error(`${path}: frozen visual file changed (${actual})`);
}

requireText('index.html', [
  '<label class="dropzone compact" for="multiFileInput">',
  'id="multiFileInput" multiple type="file"',
  '<label class="dropzone compact" for="makerFileInput">',
  'id="makerFileInput" multiple type="file"',
  'accept="image/*"'
]);
forbidText('index.html', [
  'stickerImagesPickerBtn',
  'makerImagesPickerBtn',
  'native-image-file-input',
  'direct-file-trigger'
]);

requireText('app.js', [
  "els.multiFileInput.addEventListener('change'",
  "els.makerFileInput.addEventListener('change'",
  'await addStickerFiles(files)',
  'await addMakerFiles(files)',
  'r.readAsDataURL(file)',
  'canvasToBlobReliable',
  'async function exportPng()',
  'async function exportJpg()',
  'async function exportSvg()',
  'async function exportAi()',
  'window.GoodsMakerNative?.saveBlob'
]);
forbidText('app.js', [
  'exposeNativeImageInput',
  'stickerImagesPickerBtn',
  'makerImagesPickerBtn'
]);

requireText('native/native-save-entry.js', [
  "from '@capacitor/filesystem'",
  "from '@capacitor/share'",
  'Filesystem.writeFile',
  'Filesystem.appendFile',
  'Filesystem.stat',
  'Share.share',
  'files: [uri]',
  'blob.arrayBuffer',
  'blob.size'
]);
requireText('native-save.js', [
  "registerPlugin('Filesystem')",
  "registerPlugin('Share')",
  'Filesystem.appendFile',
  'Share.share',
  'files: [uri]',
  'blob.arrayBuffer'
]);
requireText('android/app/src/main/java/com/goodsmaker/app/MainActivity.java', [
  'extends BridgeActivity'
]);
requireText('android/app/capacitor.build.gradle', [
  "project(':capacitor-filesystem')",
  "project(':capacitor-share')"
]);
requireText('scripts/build-web.mjs', [
  "'native_bridge.js'",
  "'native-save.js'"
]);

console.log('Functional wiring OK. style.css and layout.js remain byte-for-byte frozen.');
