(function () {
  'use strict';

  const forced = window.__FORCE_GOODSMAKER_NATIVE__ === true;
  const androidFileShell = location.protocol === 'file:' && (/Android/i.test(navigator.userAgent || '') || /android_asset/i.test(location.pathname || ''));
  let capacitorNative = false;
  try { capacitorNative = !!window.Capacitor?.isNativePlatform?.(); } catch (_) {}
  if (!forced && (!androidFileShell || capacitorNative)) return;
  if (window.__nativeDownloadBridgeInstalled) return;

  window.__nativeDownloadBridgeInstalled = true;
  window.__nativeDownloadBridgeVersion = '4.2-guarded-sliced-stream';

  const nativePrompt = command => window.prompt(command, '') || '';
  const utf8ToB64 = text => {
    const bytes = new TextEncoder().encode(String(text == null ? '' : text));
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x4000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x4000));
    }
    return btoa(binary);
  };
  const bytesToB64 = bytes => {
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x4000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x4000));
    }
    return btoa(binary);
  };
  const blobSliceBytes = blob => {
    if (typeof blob.arrayBuffer === 'function') {
      return blob.arrayBuffer().then(buffer => new Uint8Array(buffer));
    }
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(new Uint8Array(reader.result));
      reader.onerror = () => reject(reader.error || new Error('Blob read failed'));
      reader.readAsArrayBuffer(blob);
    });
  };
  const toast = message => {
    try { nativePrompt('__NATIVE_TOAST__\t' + utf8ToB64(message)); }
    catch (_) { /* no-op */ }
  };

  const heldBlobUrls = new Set();
  const originalRevoke = URL.revokeObjectURL.bind(URL);
  URL.revokeObjectURL = function (url) {
    if (heldBlobUrls.has(String(url))) {
      setTimeout(() => {
        heldBlobUrls.delete(String(url));
        try { originalRevoke(url); } catch (_) {}
      }, 120000);
      return;
    }
    return originalRevoke(url);
  };

  async function nativeDownloadBlob(blob, filename, hintedType, onProgress) {
    if (!(blob instanceof Blob)) return false;
    let transferId = '';
    try {
      const safeName = String(filename || 'download').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 180) || 'download';
      const mime = blob.type || hintedType || 'application/octet-stream';
      transferId = nativePrompt('__NATIVE_BEGIN__\t' + utf8ToB64(safeName) + '\t' + utf8ToB64(mime) + '\t' + String(blob.size || 0));
      if (!transferId) throw new Error('Android 저장 창을 열 수 없습니다.');

      const chunkSize = 3072;
      let written = 0;
      let index = 0;
      while (written < blob.size) {
        const end = Math.min(blob.size, written + chunkSize);
        const chunk = await blobSliceBytes(blob.slice(written, end));
        const ok = nativePrompt('__NATIVE_WRITE2__\t' + transferId + '\t' + String(chunk.byteLength) + '\t' + bytesToB64(chunk));
        if (ok !== '1') throw new Error('Android 파일 쓰기 실패: ' + written);
        written = end;
        index += 1;
        if (typeof onProgress === 'function' && ((index & 31) === 0 || written === blob.size)) {
          try { onProgress(written, blob.size); } catch (_) {}
        }
        if ((index & 31) === 0) await new Promise(resolve => setTimeout(resolve, 0));
      }
      const ok = nativePrompt('__NATIVE_FINISH__\t' + transferId);
      if (ok !== '1') throw new Error('Android 파일 저장 완료 처리에 실패했습니다.');
      transferId = '';
      return true;
    } catch (error) {
      console.error('Native download failed', error);
      if (transferId) {
        try { nativePrompt('__NATIVE_ABORT__\t' + transferId); } catch (_) {}
      }
      toast('파일 저장 데이터를 전달하지 못했습니다. 다시 시도해 주세요.');
      return false;
    }
  }

  async function nativeDownload(url, filename, hintedType, onProgress) {
    const href = String(url || '');
    if (!/^(blob:|data:)/i.test(href)) return false;
    if (href.startsWith('blob:')) heldBlobUrls.add(href);
    try {
      const response = await fetch(href);
      if (!response.ok && !href.startsWith('data:') && response.status !== 0) {
        throw new Error('Download fetch failed: ' + response.status);
      }
      return await nativeDownloadBlob(await response.blob(), filename, hintedType, onProgress);
    } catch (error) {
      console.error('Native URL download failed', error);
      toast('파일 저장 데이터를 불러오지 못했습니다. 다시 시도해 주세요.');
      return false;
    }
  }

  window.__nativeDownloadBlob = nativeDownloadBlob;
  window.__nativeDownloadUrl = nativeDownload;

  const originalClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    const href = this.href || this.getAttribute('href') || '';
    if (this.hasAttribute('download') && /^(blob:|data:)/i.test(href)) {
      nativeDownload(href, this.download || 'download', this.type || '');
      return;
    }
    return originalClick.apply(this, arguments);
  };

  document.addEventListener('click', event => {
    const anchor = event.target && event.target.closest ? event.target.closest('a[download]') : null;
    if (!anchor) return;
    const href = anchor.href || anchor.getAttribute('href') || '';
    if (!/^(blob:|data:)/i.test(href)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    nativeDownload(href, anchor.download || 'download', anchor.type || '');
  }, true);
})();
